#include <stdio.h>
#include "person.h"

void Allprint(Person person){
	printf(" << 전화번호 목록 >>\n");
	for(int i=0;i<person.size();i++){
		printf("%s\t%s",preson[i].name,person[i].phonenumber);
	}
}
