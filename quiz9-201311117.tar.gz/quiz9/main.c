#include <stdio.h>
#include "person.h"
#include "register.c"
#include "allprint.c"
#include "personalprint.c"


int main(){
	printf("전화번호 관리\n\n1. 등록\t2. 전체검색");
	printf("\t3. 특정인검색\t4. 종료\n\n");
	int command=0;
	int Threeout = 1;
	Person person[10];
	while(command!=4){
		printf("메뉴 선택: ");
		scanf("%d",&command);
	 	 switch(command){
		 case 1: Threeout = Register(person); break;
		 case 2: Allprint(person); break;	
		 case 3: Personalprint(person); break;
		 default: printf("1~4의 숫자 입력!\n"); break;
		}
		if(Threeout == 0) break;
	}
	printf("프로그램을 종료합니다\n");
}

