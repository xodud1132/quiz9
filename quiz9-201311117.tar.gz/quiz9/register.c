#include <stdio.h>
#include "person.h"

int Register(Person *person,int num){
	int count=0;
	while(count<=3){
		printf("비밀번호");
		if(count == 1 || count == 2){
			printf("(%d회실패): ",count);
		}
		else if(count==3){
			printf("(3회실패): 등록할 수 없음!\n");
			return 0;
			break;
		}
		else printf(": ");
		char pw[8];
		fgets(pw,8,stdin);
		if(pw == "qwer1234"){
			scanf("%s",*person[num].name);
			scanf("%s",*person[num].phonenumber);
			printf("%s 정보 등록 완료!",person[num].name);
			return 1;
			break;
		}
		else count++;
	}
}
