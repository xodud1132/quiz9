#ifndef _PERSON_H_
#define _PERSON_H_

struct Person{
	char name[4];
	char phonenumber[13];
};

#endif
