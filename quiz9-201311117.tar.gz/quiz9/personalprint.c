#include <stdio.h>

void Personalprint(Person person){
	printf("검색할 이름: ");
	char findname[4];
	fgets(findname,4,stdin);
	for(int i=0;i<person.size();i++){
		if(person[i].name==findname){
		 printf("%s\t%s\n",person[i].name,person[i].phonenumber);
		 break;
		}
	}
}
